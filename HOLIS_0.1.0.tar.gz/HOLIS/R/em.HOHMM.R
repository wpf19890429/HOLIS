em.HOHMM <- function(z, L, maxiter = 200)
{
  #---------------------------------------------------------------------------------

  # USAGE
  # em1.HOHMM(z, maxiter=200)
  #--------------------------------------------------------------------------------
  # ARGUMENTS
  # z: the observed data
  # maxiter: the maximum number of iterations
  #-----------------------------------------------------------------------------------
  # DETAILS
  # em1.HOHMM calculates the MLE for a second-order HMM model with hidden states being 0/1.
  # the distribution of state 0 is assumed to be N(0, 1)
  # the distribution of state 1 is assumed to be the normal mixture
  #------------------------------------------------------------------------------------
  # VALUES
  # fuction 'em1.HOHMM' gives the MLE of model parameters and HOLIS estimates for a HOHMM
  # pii: the initial state distribution
  # A=(a00 a01\\ a10 a11): the first-order transition matrix
  # B=(b000 b001\\ b010 b010\\ b100 b101\\ b110 b110): the second-order transition matrix
  # f0: the null distribution
  # f1: the non-null distribution
  # HOLIS: the HOLIS variables
  # niter: number of iterations
  #------------------------------------------------------------------------------------




  NUM <- length(z)
  ## precision tolerance level
  ptol <- 1e-4
  niter <- 0


  ## initializing model parameters

  pii.new <- c(0.5, 0.5)
  A.new <- matrix(c(0.8, 0.2, 0.4, 0.6), 2, 2, byrow = T)
  B.new <- array(0.5, c(2, 2, 2))
  f0 <- c(0, 1)
  f1.new <- matrix(c(1:L, rep(1, L)),
                   nrow = L,
                   ncol = 2,
                   byrow = FALSE)
  pc.new <- rep(1 / L, L)
  f0z <- dnorm(z, f0[1], f0[2])
  diff <- 1

  pb <- PB(Methods = "em1.HOHMM", Rep = maxiter)


  while (diff > ptol && niter < maxiter)
  {
    niter <- niter + 1
    pb$tick()

    pii.old <- pii.new
    A.old <- A.new
    B.old <- B.new
    f1.old <- f1.new
    pc.old <- pc.new

    ## updating the variables

    bwfw.res <- bwfw.HOHMM(z, pii.new, A.new, B.new, f0, f1.new, pc.new)
    alpha <- bwfw.res$bw
    beta <- bwfw.res$fw
    f1z <- rep(0, NUM)
    for (mc in 1:L)
    {
      f1z <- f1z + pc.new[mc] * dnorm(z, f1.new[mc, 1], f1.new[mc, 2])
    }


    xi <- array(0, dim = c(NUM - 1, 2, 2, 2))
    b1 <- rep(0, NUM - 1)
    for (j in 2:(NUM - 1))
    {
      for (p in 1:2)
        for (q in 1:2)
        {
          xi[j, p, q, 1] <-
            alpha[j, p, q] * beta[j + 1, q, 1] * f0z[j + 1] * B.new[p, q, 1]
          xi[j, p, q, 2] <-
            alpha[j, p, q] * beta[j + 1, q, 2] * f1z[j + 1] * B.new[p, q, 2]
        }
      b1[j] <-
        xi[j, 1, 1, 1] + xi[j, 1, 1, 2] + xi[j, 1, 2, 1] + xi[j, 1, 2, 2] +
        xi[j, 2, 1, 1] + xi[j, 2, 1, 2] + xi[j, 2, 2, 1] + xi[j, 2, 2, 2]
      for (p in 1:2)
        for (q in 1:2)
          for (r in 1:2)
            xi[j, p, q, r] <- 1 / b1[j] * xi[j, p, q, r]
    }

    dgamma <- array(0, dim = c(NUM - 1, 2, 2))
    for (j in 2:(NUM - 1))
      for (p in 1:2)
        for (q in 1:2)
          dgamma[j, p, q] <- sum(xi[j, p, q,])


    gamma <- 1 - bwfw.res$HOLIS

    # weight variables

    omega <- matrix(0,
                    nrow = NUM,
                    ncol = L,
                    byrow = TRUE)
    for (mc in 1:L)
    {
      f1z.c <- dnorm(z, mean = f1.new[mc, 1], sd = f1.new[mc, 2])
      omega[, mc] <- pc.new[mc] * gamma * f1z.c / f1z
    }



    ## updating the parameter estimates


    # updating pii

    pii.new <- xi[2, , 1, 1] + xi[2, , 1, 2] + xi[2, , 2, 1] + xi[2, , 2, 2]


    # updating A

    for (p in 1:2)
      for (q in 1:2)
        A.new[p, q] <-
      sum(xi[2, p, q,]) / (sum(xi[2, p, 1,]) + sum(xi[2, p, 2,]))


    # updating B

    for (p in 1:2)
      for (q in 1:2)
        for (r in 1:2)
          B.new[p, q, r] <- sum(xi[, p, q, r]) / sum(dgamma[, p, q])

    # updating f1

    for (mc in 1:L)
    {
      # probability weights

      q1 <- sum(omega[, mc])
      q2 <- sum(gamma)
      pc.new[mc] <- q1 / q2


      # means

      q3 <- sum(omega[, mc] * z)
      f1.new[mc, 1] <- q3 / q1

      # sds

      q4 <- sum(omega[, mc] * (z - f1.new[mc, 1]) * (z - f1.new[mc, 1]))
      f1.new[mc, 2] <- sqrt(q4 / q1)
    }




    df1 <- abs(B.old - B.new)
    df2 <- abs(f1.old - f1.new)
    diff <- max(df1, df2)
  }


  # return the results of the E-M algorithm

  em.var <-
    list(
      pii = pii.new,
      A = A.new,
      B = B.new,
      f1 = f1.new,
      pc = pc.new,
      ni = niter
    )
  return(em.var)

}
