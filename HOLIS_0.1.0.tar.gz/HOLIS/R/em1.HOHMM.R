em1.HOHMM <- function(z, maxiter = 200)
{
  #----------------------------------------------------------------------------------------
  # USAGE
  # em1.HOHMM(z, maxiter=200)
  #-----------------------------------------------------------------------------------------
  # ARGUMENTS
  # z: the observed data
  # maxiter: the maximum number of iterations
  #--------------------------------------------------------------------------------------------
  # DETAILS
  # em1.HOHMM calculates the MLE for a second-order HMM model with hidden states being 0/1.
  # the distribution of state 0 is assumed to be N(0, 1)
  # the distribution of state 1 is assumed to be normal
  #----------------------------------------------------------------------------------------
  # VALUES
  # fuction 'em1.HOHMM' gives the MLE of model parameters and HOLIS estimates for a HOHMM
  # pii: the initial state distribution
  # A=(a00 a01\\ a10 a11): the first-order transition matrix
  # B=(b000 b001\\ b010 b010\\ b100 b101\\ b110 b110): the second-order transition matrix
  # f0: the null distribution
  # f1: the non-null distribution
  # HOLIS: the HOLIS variables
  # niter: number of iterations
  #-----------------------------------------------------------------------------------------


  NUM <- length(z)
  ## precision tolerance level
  ptol <- 1e-4
  niter <- 0


  ## initializing model parameters

  pii.new <- c(0.5, 0.5)
  A.new <- matrix(c(0.8, 0.2, 0.4, 0.6), 2, 2, byrow = T)
  B.new <- array(0.5, c(2, 2, 2))
  f0 <- c(0, 1)
  f1.new <- c(2, 1)
  f0z <- dnorm(z, f0[1], f0[2])
  diff <- 1

  pb <- PB(Methods = "em1.HOHMM", Rep = maxiter)


  while (diff > ptol && niter < maxiter)
  {
    niter <- niter + 1
    pb$tick()

    pii.old <- pii.new
    A.old <- A.new
    B.old <- B.new
    f1.old <- f1.new

    ## updating the variables

    bwfw1.res <- bwfw1.HOHMM(z, pii.new, A.new, B.new, f0, f1.new)
    alpha <- bwfw1.res$bw
    beta <- bwfw1.res$fw
    f1z <- dnorm(z, f1.new[1], f1.new[2])

    xi <- array(0, dim = c(NUM - 1, 2, 2, 2))
    b1 <- rep(0, NUM - 1)
    for (j in 2:(NUM - 1))
    {
      for (p in 1:2)
        for (q in 1:2)
        {
          xi[j, p, q, 1] <-
            alpha[j, p, q] * beta[j + 1, q, 1] * f0z[j + 1] * B.new[p, q, 1]
          xi[j, p, q, 2] <-
            alpha[j, p, q] * beta[j + 1, q, 2] * f1z[j + 1] * B.new[p, q, 2]
        }
      b1[j] <-
        xi[j, 1, 1, 1] + xi[j, 1, 1, 2] + xi[j, 1, 2, 1] + xi[j, 1, 2, 2] +
        xi[j, 2, 1, 1] + xi[j, 2, 1, 2] + xi[j, 2, 2, 1] + xi[j, 2, 2, 2]
      for (p in 1:2)
        for (q in 1:2)
          for (r in 1:2)
            xi[j, p, q, r] <- 1 / b1[j] * xi[j, p, q, r]
    }

    dgamma <- array(0, dim = c(NUM - 1, 2, 2))
    for (j in 2:(NUM - 1))
      for (p in 1:2)
        for (q in 1:2)
          dgamma[j, p, q] <- sum(xi[j, p, q,])



    ## updating the parameter estimates


    # updating pii

    pii.new <- xi[2, , 1, 1] + xi[2, , 1, 2] + xi[2, , 2, 1] + xi[2, , 2, 2]


    # updating A

    for (p in 1:2)
      for (q in 1:2)
        A.new[p, q] <-
      sum(xi[2, p, q,]) / (sum(xi[2, p, 1,]) + sum(xi[2, p, 2,]))


    # updating B

    for (p in 1:2)
      for (q in 1:2)
        for (r in 1:2)
          B.new[p, q, r] <- sum(xi[, p, q, r]) / sum(dgamma[, p, q])

    # updating f1

    gamma <- 1 - bwfw1.res$HOLIS

    # updating the mean

    q1 <- sum(gamma)
    q2 <- sum(gamma * z)
    mu1 <- q2 / q1

    # updating the standard deviation

    q3 <- sum(gamma * (z - mu1) * (z - mu1))
    sd1 <- sqrt(q3 / q1)
    f1.new <- c(mu1, sd1)


    df1 <- abs(A.old - A.new)
    df1 <- abs(B.old - B.new)
    df2 <- abs(f1.old - f1.new)
    diff <- max(df1, df2)
  }


  # return the results of the E-M algorithm

  em.var <- list(
    pii = pii.new,
    A = A.new,
    B = B.new,
    f1 = f1.new,
    ni = niter
  )
  return(em.var)

}
