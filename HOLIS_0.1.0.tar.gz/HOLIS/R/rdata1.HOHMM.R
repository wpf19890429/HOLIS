rdata1.HOHMM <- function(NUM, pii, A, B, f0, f1)
{
  ## NUM is the number of hypotheses
  theta <- rep(0, NUM)
  z <- rep(0, NUM)


  ## generating the states
  # initial state
  theta[1] <- sample(0:1,
                     size = 1,
                     replace = FALSE,
                     prob = pii)
  theta[2] <-
    sample(0:1,
           size = 1,
           replace = FALSE,
           prob = A[theta[1] + 1,])


  # other states
  for (i in 3:NUM)
  {
    if (theta[i - 2] == 0 && theta[i - 1] == 0)
      theta[i] <- rbinom(1, 1, B[1, 1, 2])
    else if (theta[i - 2] == 0 && theta[i - 1] == 1)
      theta[i] <- rbinom(1, 1, B[1, 2, 2])
    else if (theta[i - 2] == 1 && theta[i - 1] == 0)
      theta[i] <- rbinom(1, 1, B[2, 1, 2])
    else
      theta[i] <- rbinom(1, 1, B[2, 2, 2])
  }


  ## generating the observations
  for (i in 1:NUM)
  {
    if (theta[i] == 0)
    {
      z[i] <- rnorm(1, mean = f0[1], sd = f0[2])
    }
    else
    {
      z[i] <- rnorm(1, mean = f1[1], sd = f1[2])
    }
  }

  data <- list(theta = theta, z = z)
  return (data)

}
