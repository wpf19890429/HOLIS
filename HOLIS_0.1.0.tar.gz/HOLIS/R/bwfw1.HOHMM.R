bwfw1.HOHMM <- function(z, pii, A, B, f0, f1)
{
  #--------------------------------------
  # VALUES
  # alpha: rescaled backward variables
  # beta: rescaled forward variables
  #--------------------------------------
  # Initialize

  NUM <- length(z)
  # Densities
  f0z <- dnorm(z, f0[1], f0[2])
  f1z <- dnorm(z, f1[1], f1[2])

  ## the backward-forward procedure

  # a. the backward variables
  # --rescaled

  alpha <- array(0, dim = c(NUM, 2, 2))
  # scaling variable c_0
  c0 <- rep(0, NUM)
  c0[1] <- 1

  alpha[2, 1, 1] <- f0z[1] * f0z[2] * pii[1] * A[1, 1]
  alpha[2, 2, 1] <- f1z[1] * f0z[2] * pii[2] * A[2, 1]
  alpha[2, 1, 2] <- f0z[1] * f1z[2] * pii[1] * A[1, 2]
  alpha[2, 2, 2] <- f1z[1] * f1z[2] * pii[2] * A[2, 2]
  c0[2] <- 1 / (sum(alpha[2, 1,]) + sum(alpha[2, 2,]))
  alpha[2, 1,] <- c0[2] * alpha[2, 1,]
  alpha[2, 2,] <- c0[2] * alpha[2, 2,]

  for (i in 2:(NUM - 1))
  {
    alpha[i + 1, 1, 1] <-
      (alpha[i, 1, 1] * B[1, 1, 1] + alpha[i, 2, 1] * B[2, 1, 1]) * f0z[i + 1]
    alpha[i + 1, 2, 1] <-
      (alpha[i, 1, 2] * B[1, 2, 1] + alpha[i, 2, 2] * B[2, 2, 1]) * f0z[i + 1]
    alpha[i + 1, 1, 2] <-
      (alpha[i, 1, 1] * B[1, 1, 2] + alpha[i, 2, 1] * B[2, 1, 2]) * f1z[i + 1]
    alpha[i + 1, 2, 2] <-
      (alpha[i, 1, 2] * B[1, 2, 2] + alpha[i, 2, 2] * B[2, 2, 2]) * f1z[i + 1]
    c0[i + 1] <-
      1 / (sum(alpha[i + 1, 1,]) + sum(alpha[i + 1, 2,]))
    alpha[i + 1, 1,] <- c0[i + 1] * alpha[i + 1, 1,]
    alpha[i + 1, 2,] <- c0[i + 1] * alpha[i + 1, 2,]
  }

  # b. the forward variables
  # --rescaled

  beta <- array(0, dim = c(NUM, 2, 2))
  b0 <- rep(0, NUM)
  beta[NUM, 1,] <- 1 / 4
  beta[NUM, 2,] <- 1 / 4

  for (i in (NUM - 1):2)
  {
    beta[i, 1, 1] <-
      beta[i + 1, 1, 1] * f0z[i + 1] * B[1, 1, 1] + beta[i + 1, 1, 2] * f1z[i +
                                                                              1] * B[1, 1, 2]
    beta[i, 1, 2] <-
      beta[i + 1, 2, 1] * f0z[i + 1] * B[1, 2, 1] + beta[i + 1, 2, 2] * f1z[i +
                                                                              1] * B[1, 2, 2]
    beta[i, 2, 1] <-
      beta[i + 1, 1, 1] * f0z[i + 1] * B[2, 1, 1] + beta[i + 1, 1, 2] * f1z[i +
                                                                              1] * B[2, 1, 2]
    beta[i, 2, 2] <-
      beta[i + 1, 2, 1] * f0z[i + 1] * B[2, 2, 1] + beta[i + 1, 2, 2] * f1z[i +
                                                                              1] * B[2, 2, 2]
    b0[i] <-
      1 / (sum(beta[i, 1,]) + sum(beta[i, 2,]))
    beta[i, 1,] <- b0[i] * beta[i, 1,]
    beta[i, 2,] <- b0[i] * beta[i, 2,]
  }

  HOLIS <- rep(0, NUM)

  for (k in 2:NUM)
  {
    q1 <- sum(alpha[k, , 1] * beta[k, , 1])
    q2 <- sum(alpha[k, , 2] * beta[k, , 2])
    HOLIS[k] <- q1 / (q1 + q2)
  }
  q3 <- sum(alpha[2, 1,] * beta[2, 1,])
  q4 <- sum(alpha[2, 2,] * beta[2, 2,])
  HOLIS[1] <- q3 / (q3 + q4)

  bwfw.var <- list(
    bw = alpha,
    fw = beta,
    HOLIS = HOLIS,
    c0 = c0
  )
  return(bwfw.var)
}
